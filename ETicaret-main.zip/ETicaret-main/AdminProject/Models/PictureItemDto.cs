﻿namespace AdminProject.Models
{
    public class PictureItemDto
    {
        public string MinPicture { get; set; }
        public string BigPicture { get; set; }
        public bool IsShowcase { get; set; }
    }
}