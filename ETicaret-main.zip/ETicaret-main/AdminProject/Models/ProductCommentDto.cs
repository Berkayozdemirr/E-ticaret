﻿namespace AdminProject.Models
{
    public class ProductCommentDto
    {
        public string UserNameSurname { get; set; }
        public string Comment { get; set; }
        public string DateTime { get; set; }
    }
}