﻿namespace AdminProject.Models
{
    public class PreSaveOrderInfo
    {
        public string OrderNr { get; set; }
        public string DeliveryId { get; set; }
        public string InvoiceId { get; set; }
        public string OrderNote { get; set; }
    }
}