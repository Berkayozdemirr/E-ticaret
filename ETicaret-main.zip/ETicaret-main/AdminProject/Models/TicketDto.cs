﻿namespace AdminProject.Models
{
    public class TicketDto
    {
        public string OrderNr { get; set; }
        public string Message { get; set; }
    }
}