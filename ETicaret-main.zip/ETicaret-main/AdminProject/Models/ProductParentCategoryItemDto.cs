﻿namespace AdminProject.Models
{
    public class ProductParentCategoryItemDto
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Url { get; set; }
        public string Picture { get; set; }
        public int ProductCount { get; set; }
    }
}