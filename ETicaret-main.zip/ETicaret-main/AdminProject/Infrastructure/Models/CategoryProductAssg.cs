﻿namespace AdminProject.Infrastructure.Models
{
    public class CategoryProductAssg
    {
        public int Id { get; set; }
        public int CategoryId { get; set; }
        public int ProductId { get; set; }
    }
}