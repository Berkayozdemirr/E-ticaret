﻿namespace AdminProject.Infrastructure.Models
{
    public class ProductMeasureAssg
    {
        public int Id { get; set; }
        public int ProductId { get; set; }
        public int MeasureId { get; set; }
    }
}