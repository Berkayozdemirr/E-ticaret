﻿using System.Collections.Generic;
using AdminProject.Infrastructure.Models;

namespace AdminProject.Services.Interface
{
    public interface ISliderService
    {
        List<Slider> List();
    }
}