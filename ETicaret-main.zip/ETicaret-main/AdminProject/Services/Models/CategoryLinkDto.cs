﻿namespace AdminProject.Services.Models
{
    public class CategoryLinkDto
    {
        public string SingleName { get; set; }
        public string Name { get; set; }
        public string Url { get; set; }
    }
}