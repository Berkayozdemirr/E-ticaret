﻿namespace AdminProject.Services.Models
{
    public class ProductPropertyModel
    {
        public string PropertyName { get; set; }
        public string PropertyValue { get; set; }
    }
}